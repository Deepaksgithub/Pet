/*Author Deepak Appu*/

package com.pet.acceptancetest.stepdefinitions;

import org.junit.runner.RunWith;

import com.pet.acceptancetest.apisteps.ManagePet;
import com.pet.acceptancetest.common.CommonMethods;
import com.pet.acceptancetest.utils.EnvironmentSetup;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import io.restassured.RestAssured;
import net.serenitybdd.junit.runners.SerenityRunner;
import net.thucydides.core.annotations.Steps;

@RunWith(SerenityRunner.class)

public class PetManagementSteps {

	@Steps
	ManagePet mgPet;


	@Given("^Add a new pet with id ,category name, petname , status, tag name, photourl.$")
	public void addPet() {

		mgPet.addPetDetails();
	}

	@Then("^verify The Pet was created with correct data$")
	public void verifyResponse() {
		mgPet.verifyData();
	}

	@Given("^Update the pet name$")
	public void updatePet() {

		mgPet.updatePet();
	}

	@Then("^delete the record$")
	public void deleteRecord() {

		mgPet.deletePet();
	}

}
