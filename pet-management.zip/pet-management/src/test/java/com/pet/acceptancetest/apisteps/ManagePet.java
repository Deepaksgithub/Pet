package com.pet.acceptancetest.apisteps;

import java.io.File;

import org.junit.Assert;

import com.pet.acceptancetest.common.CommonMethods;
import com.pet.acceptancetest.utils.EnvironmentSetup;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import net.thucydides.core.annotations.Step;

public class ManagePet {
	String value;
	String id;
	CommonMethods commonObj;


	@Step
	public void addPetDetails() {

		RestAssured.basePath = "/pet";
		try {
			File file = new File(System.getProperty("user.dir") + "/src/test/resources/pet_schema.json");
			Response res = RestAssured.given().body(file).when().contentType(ContentType.JSON).post();

			//verifying the output data from the response
			value=res.path("name");
			id=res.path("id");

			if(value=="Brownie" && id==EnvironmentSetup.petId.toString()){
				System.out.println("Values are exact");
			}
			else{
				System.out.println("Values do not match");
			}
			Assert.assertEquals("Status Check Login", 200, res.getStatusCode());
			System.out.println(res.asString());

		}
		catch(Exception e) {
			e.printStackTrace();
		}

	}

	public void verifyData(){
		//verify the output response schema 
		commonObj = new CommonMethods();
		commonObj.testJsonSchema(RestAssured.baseURI+"pet/"+EnvironmentSetup.petId, "pet_schema.json");

	}

	@Step
	public void updatePet() {

		//update the json with name
		RestAssured.basePath = "pet";
		try {
			File file = new File(System.getProperty("user.dir") + "/src/test/resources/update_name.json");
			Response res = RestAssured.given().body(file).when().contentType(ContentType.JSON).header("Accept", "application/json").put();
			Assert.assertEquals("Status Check Login", 200, res.getStatusCode());
			System.out.println(res.asString());

		}
		catch(Exception e)
		{
			e.printStackTrace();
		}



	}

	@Step
	public void deletePet() {
		//delete the json with id as 10
		Response response = null;

		try {
			response = RestAssured.given().contentType(ContentType.JSON).header("Accept", "application/json")
					.delete("" +EnvironmentSetup.petId);
		} catch (Exception e) {
			e.printStackTrace();
		}



	}



}
