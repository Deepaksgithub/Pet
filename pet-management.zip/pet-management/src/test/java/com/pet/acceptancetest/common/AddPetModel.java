package com.pet.acceptancetest.common;

public class AddPetModel {

  private String Id;
  private String Category_name;
  private String Pet_name;
  private String Status;
  private String tagName;
  private String photoUrl;
  
public String getId() {
	return Id;
}
public void setId(String id) {
	Id = id;
}
public String getCategory_name() {
	return Category_name;
}
public void setCategory_name(String category_name) {
	Category_name = category_name;
}
public String getPet_name() {
	return Pet_name;
}
public void setPet_name(String pet_name) {
	Pet_name = pet_name;
}
public String getStatus() {
	return Status;
}
public void setStatus(String status) {
	Status = status;
}
public String getTagName() {
	return tagName;
}
public void setTagName(String tagName) {
	this.tagName = tagName;
}
public String getPhotoUrl() {
	return photoUrl;
}
public void setPhotoUrl(String photoUrl) {
	this.photoUrl = photoUrl;
}
  
  


}