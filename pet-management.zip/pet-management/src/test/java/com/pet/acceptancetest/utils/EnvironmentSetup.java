package com.pet.acceptancetest.utils;

import io.restassured.RestAssured;
import net.thucydides.core.util.EnvironmentVariables;
import net.thucydides.core.util.SystemEnvironmentVariables;

public class EnvironmentSetup {
	 
	static EnvironmentVariables variables = SystemEnvironmentVariables.createEnvironmentVariables();
	public static String petId;

	public static void setEnvironment()  {
		
		// Use this Class if you need to setup mutiple environments
		petId=variables.getProperty("env.petId");
		RestAssured.baseURI = variables.getProperty("env.value");
		
		
       


	}
	

}




