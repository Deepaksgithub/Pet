package com.pet.acceptancetest;

import cucumber.api.CucumberOptions;
import net.serenitybdd.cucumber.CucumberWithSerenity;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;

import com.pet.acceptancetest.utils.EnvironmentSetup;

@RunWith(CucumberWithSerenity.class)
@CucumberOptions(plugin = {"pretty"},features = "src/test/resources/features")

public class CucumberTestSuite {

	@BeforeClass
	public static void setUp(){
		
		EnvironmentSetup.setEnvironment();

	}

	@AfterClass
	public static void tearDown(){

	}
}
