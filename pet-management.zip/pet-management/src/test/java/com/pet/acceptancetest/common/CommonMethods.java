package com.pet.acceptancetest.common;

import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchemaInClasspath;

import io.restassured.RestAssured;

public class CommonMethods {

	public void testJsonSchema(String url, String jsonFile) {
		// TODO Auto-generated method stub

		RestAssured
		.given()
		.contentType("application/json")
		.when()
		.get(url)				
		.then()
		.assertThat()		
		.body(matchesJsonSchemaInClasspath(jsonFile));
		

	}

}
